package Exercise5_2;

public class MTBooks implements IBooks {
	/**
	 * Translate this into object
	 */
	@Override
	public String toString() {
		
		return "";
	}

}
