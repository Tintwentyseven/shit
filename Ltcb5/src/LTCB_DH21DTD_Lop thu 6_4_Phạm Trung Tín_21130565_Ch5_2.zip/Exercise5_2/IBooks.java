package Exercise5_2;

public interface IBooks {

}
