package Exercise5_5;

import junit.framework.TestCase;

public class FatherTest extends TestCase {
	public void testConstructor() {
	Father f1 = new Father("???", "");
	System.out.print(f1);
	
	

}
}
