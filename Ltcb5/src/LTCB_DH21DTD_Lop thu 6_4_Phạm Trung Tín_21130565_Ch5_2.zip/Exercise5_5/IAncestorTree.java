package Exercise5_5;

public interface IAncestorTree {
	/**
	 * Translate this into object
	 * @return
	 */
	@Override
	String toString();

}
