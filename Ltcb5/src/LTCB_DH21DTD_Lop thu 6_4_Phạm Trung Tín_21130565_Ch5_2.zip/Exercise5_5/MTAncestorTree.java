package Exercise5_5;

public class MTAncestorTree implements IAncestorTree {
	/**
	 * Translate this into object
	 */
	@Override
	public String toString() {
		
		return "";
	}

}
