package Exercise5_5;

import junit.framework.TestCase;

public class PersonTest extends TestCase {
	public void testConstructor() {
	Person p1 = new Person("Angela", 1936);
	System.out.print(p1);

}
}
