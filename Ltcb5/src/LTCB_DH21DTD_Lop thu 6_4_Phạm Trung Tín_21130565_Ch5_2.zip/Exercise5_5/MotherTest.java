package Exercise5_5;

import junit.framework.TestCase;

public class MotherTest extends TestCase {
	public void testConstructor() {
	Mother m1 = new Mother("???", "");
	System.out.print(m1);

}
}
