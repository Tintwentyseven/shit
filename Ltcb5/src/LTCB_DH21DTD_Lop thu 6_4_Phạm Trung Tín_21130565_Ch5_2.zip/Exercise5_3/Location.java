package Exercise5_3;

public class Location {
	private int x;
	private int y;
	private String name;
	/**
	 * This is constructor of Location
	 * Example
	 * Location l1 = new Location(1, 2, "s");
	 * @param x: gia tri
	 * @param y: gia tri
	 * @param name: ten
	 */
	public Location(int x, int y, String name) {
		super();
		this.x = x;
		this.y = y;
		this.name = name;
	}

}
