package Exercise5_3;



public class Source extends ARiver {
	/**
     * This is constructor of Source
     * Example
     * Source s1 = new Source(new Location(1, 1, "s"), 120.0);
     *@param location: vi tri
     *@paran length: do dai
     * 
     */

	public Source(Location location, double length) {
		super(location, length);
		
		
	}
    
  
	

}
