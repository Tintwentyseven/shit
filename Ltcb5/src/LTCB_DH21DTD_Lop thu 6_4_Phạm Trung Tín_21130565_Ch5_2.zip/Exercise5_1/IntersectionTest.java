package Exercise5_1;

import junit.framework.TestCase;

public class IntersectionTest extends TestCase {
	public void testConstructor() {
		Intersection i1 = new Intersection(1, 10);
		System.out.print(i1);
	}

}
