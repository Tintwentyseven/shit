package Exercise5_1;

public interface IHouses {

}
