package Exercise5_1;

public class MTHouses implements IHouses {
	@Override
	public String toString() {
		
		return "";
	}

}
