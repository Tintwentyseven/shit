package Exercise5_4;

public interface IGrades {

}
