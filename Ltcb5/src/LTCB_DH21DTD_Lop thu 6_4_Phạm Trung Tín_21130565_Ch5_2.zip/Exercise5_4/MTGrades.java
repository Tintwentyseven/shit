package Exercise5_4;

public class MTGrades implements IGrades {
	@Override
	public String toString() {
	
		return "";
	}

}
