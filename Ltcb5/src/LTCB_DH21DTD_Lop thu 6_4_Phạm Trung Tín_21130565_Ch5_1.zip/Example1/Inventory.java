package Example1;

public interface Inventory {

}
