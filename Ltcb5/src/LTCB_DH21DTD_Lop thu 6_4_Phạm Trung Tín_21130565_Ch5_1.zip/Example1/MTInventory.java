package Example1;

public class MTInventory implements Inventory {

	@Override
	public String toString() {
	
		return "";
	}
	

}
