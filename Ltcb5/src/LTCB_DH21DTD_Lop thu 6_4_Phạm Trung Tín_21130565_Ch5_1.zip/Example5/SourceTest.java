package Example5;

import junit.framework.TestCase;

public class SourceTest extends TestCase {
	public void testConstructor() {
		Source s1 = new Source(new Location(1, 1, "s"), 120.0);
	}

}
