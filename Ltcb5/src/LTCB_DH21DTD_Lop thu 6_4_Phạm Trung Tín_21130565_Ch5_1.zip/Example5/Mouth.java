package Example5;

public class Mouth {
	private Location location;
	private ARiver river;
	/**
	 * This is constructor of Mouth
	 * Example
	 * Mouth m = new Mouth(new Location(7, 5, "m"), a);
	 * @param location: vi tri
	 * @param river: con song
	 */
	public Mouth(Location location, ARiver river) {
		super();
		this.location = location;
		this.river = river;
	}
	
	}
	


