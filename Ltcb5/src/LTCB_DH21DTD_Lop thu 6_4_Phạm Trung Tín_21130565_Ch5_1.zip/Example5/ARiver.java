package Example5;

public abstract class ARiver {
	protected Location location;
	protected double length;
	/**
	 * This is constructor of ARiver
	 * ARiver s = new ARiver(new Location(1, 1, "s"), 120.0);
	 * @param location: vi tri
	 * @param length: do dai
	 */
	public ARiver(Location location, double length) {
		super();
		this.location = location;
		this.length = length;
	}

		
		
	}
	


