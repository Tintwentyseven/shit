package Example5;

import junit.framework.TestCase;

public class LocationTest extends TestCase {
	public void testConstructor() {
		Location l1 = new Location(1, 2, "s");
	}

}
