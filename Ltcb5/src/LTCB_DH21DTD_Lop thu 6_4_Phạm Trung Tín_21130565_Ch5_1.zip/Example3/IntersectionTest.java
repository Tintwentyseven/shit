package Example3;

import junit.framework.TestCase;

public class IntersectionTest extends TestCase {
	public void testConstructor() {
		 Intersection i1 = new Intersection(5, 50);
		 System.out.print(i1);
	}

}
