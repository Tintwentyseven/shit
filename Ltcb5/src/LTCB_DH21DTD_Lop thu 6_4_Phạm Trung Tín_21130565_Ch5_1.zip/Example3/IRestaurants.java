package Example3;

public interface IRestaurants {

}
