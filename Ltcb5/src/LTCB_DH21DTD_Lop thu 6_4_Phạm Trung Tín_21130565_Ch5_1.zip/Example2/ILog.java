package Example2;

public interface ILog {

}
