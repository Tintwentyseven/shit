package Example4;

public interface IShape {

}
