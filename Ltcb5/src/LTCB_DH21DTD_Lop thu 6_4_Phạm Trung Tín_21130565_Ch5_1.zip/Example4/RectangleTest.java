package Example4;

import junit.framework.TestCase;

public class RectangleTest extends TestCase {
	public void testConstructor() {
		Rectangle r1 = new Rectangle(new CartPt(2,3), 5, 7);
		
	}

}
