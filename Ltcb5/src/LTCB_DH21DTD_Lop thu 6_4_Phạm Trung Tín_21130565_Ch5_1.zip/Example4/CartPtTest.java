package Example4;

import junit.framework.TestCase;

public class CartPtTest extends TestCase {
	public void testConstructor() {
		CartPt c1 = new CartPt(4,3);
		System.out.print(c1);
	}

}
