package Example4;

public class Rectangle extends ASingleShape {
	private int width;
	private int height;
	/**
	 * This is constructor of Rectangle
	 * Example
	 * Rectangle(new CartPt(2,3), 5, 7);
	 * @param location: vi tri
	 * @param width: chieu rong
	 * @param height: chieu cao
	 */
	public Rectangle(CartPt location, int width, int height) {
		super(location);
		this.width = width;
		this.height = height;
	}

	
	}



