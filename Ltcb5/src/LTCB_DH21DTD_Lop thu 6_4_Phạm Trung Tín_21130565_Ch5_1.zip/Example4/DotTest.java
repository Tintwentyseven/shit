package Example4;

import junit.framework.TestCase;

public class DotTest extends TestCase {
	public void testConstructor() {
		 Dot d1 = new Dot(new CartPt(1,2));
		 
	}

}
