package Example4;

import junit.framework.TestCase;

public class CircleTest extends TestCase {
	public void testConstructor() {
		Circle o1 = new Circle( new CartPt(4,3), 10);
		
	}

}
