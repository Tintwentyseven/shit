package Example4;

public class Dot extends ASingleShape {
    /**
     * This is constructor of Dot
     * Example
     * Dot d1 = new Dot(new CartPt(1,2);
     * @param location: vi tri
     */

	public Dot(CartPt location) {
		super(location);
		// TODO Auto-generated constructor stub
	}
	
	}


